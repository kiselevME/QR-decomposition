#ifndef header_h
#define header_h
int entermatrix(double*, char*, int, int);
int solve(int, double*, double*, double*, double*, double); 
double norma1(int, double*, double*);
double norma2(int, double*, double*);  
double norm_matrix(int, double*);
void outmatrix(int, int, int, double*); 
#endif//header

